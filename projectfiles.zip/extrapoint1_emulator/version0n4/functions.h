#ifndef FUNCTIONS_H
#define FUNCTIONS_H
void frame1(void);
void frame2(void);
void buttons (void);
void ageTamagotchi(int hr, int min, int sec);
void batterie(void);
void gestiscifame(int countfame);
void gestiscifelicita(int countfelicita);
void buttonleft(void);
void buttonright(void);
void buttonsneri(void);
void mangiatasnack(void);
void mangiatameal(void);
void animazionerunaway(void);
void animazionerunaway2(void);
void displayreset(void);
void ageTamagotchired(int hr, int min, int sec);
void batteriered(void);
void gestiscifamered(int counterfame);
void gestiscifelicitared(int counterfelicita);

#endif
